﻿//Hw 4, Lior Lugasi, 203962006, Roy Greenberg, 201559994//


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Dictionary{	//The struct of the element in dictionary//
	char *key;
	char *value;
} Dictionary;


typedef struct Node {		//The struct of the each node in the linked list//
	char *string;
	struct Node *next;
}Node;

int init_hash(int size);			//For initialize the hashtable//
int insert(char* key, char* value, int(*hash)(char*, int));			//Insert element to the hashtable//
int contains(char* key, int(*hash)(char*, int));		//Function that checks if the requested key is in the hashtable//
char* get(char* key, int(*hash)(char*, int));			//Function that return the value of the key//
int delete(char* key, int(*hash)(char*, int));			//Function that delete element by his key//
Node* get_sorted_keys(char** (*sort_function)(char** hashtableay_To_Sort, int size));	//A function that returns a linked list of all the keys are sorted in alphabetical order//
Node* get_sorted_values(char** (*sort_function)(char** hashtableay_To_Sort, int size));		//A function that returns a linked list of all the values are sorted in alphabetical order//
int hash_sum(char* key, int M);		//The function calculates a hash of the scheme by ASCII values ​​of each character//
int hash_prime(char* key, int M); //The function calculates the hash by ASCII values ​​schema of each character, but doubles every ASCII value of the initial number//
void OccupiedZone();		//If the table occupancy exceeds 75% should be increased according to table 2//
void FreeHashTable(int index, Dictionary *arr);		//Free each node in the hashtable//
char** InsertionSort(char **arr,int size);		//Func of Insertion sort//
char** MergeSort(char **arr,int size);			//Merge sort, recursive function//
void Merge(char **arr, char **left, int cleft, char **rgit, int cright);		//Merge two arrays to one//
Node *addNode(Node *list, char* str);			//Add node to the linked list//

Dictionary *hashtable = NULL;		//Global variable, the hashtable//
int M;				//Global variable, the size of the hastable//

void main(){
	int flag,i=0,countkey=0,countval=0;
	Node *ptr, *sortkey,*sortval;
	flag=init_hash(1);		//Calling to init function//
	while (flag == -1){			//If the size is less then 1//
		flag = init_hash(10);
	}
	printf("If the insert action succeeded print success, else failure\n");
	if (insert("first", "lior", hash_sum) == 1)		//If the insert succeded//
		printf("success\n");
	else
		printf("failure\n");
	printf("If the key 'first' is in the hashtable print success, else failure\n");
	if(contains("first", hash_sum)==1)			//If the requested key is in the hashtable//
		printf("success\n");
	else
		printf("failure\n");
	printf("The value for key 'first' is:\n");	//The requested value for the key in the hashtable//	
	printf("%s\n", get("first", hash_sum));
	printf("If the delete of key 'first' succeeded print success, else failure\n");	//Delete element by his key//
	if (delete("first", hash_sum) == 1)
		printf("success\n");
	else
		printf("failure\n");
	insert("first", "lsce", hash_sum);
	insert("second", "bsce", hash_sum);
	insert("third", "sce", hash_sum);
	printf("Sorting keys(merge sort):\n");		//Merger sorting by keys//
	sortkey = get_sorted_keys(MergeSort);
	for (ptr = sortkey; ptr != NULL; ptr = ptr->next){
		printf("%s\t", ptr->string);
		countkey++;
	}
	printf("\n");
	sortval = get_sorted_values(InsertionSort);	//Insertion sorting by values//
	printf("Sorting values(insertion sort):\n");
	for (ptr = sortval; ptr != NULL; ptr = ptr->next){
		printf("%s\t", ptr->string);
		countval++;
	}
	printf("\n");
	for (ptr = sortval; ptr != NULL; ptr = ptr->next){
		FreeHashTable(i, hashtable);
		i++;
	}
	for (i = 0; i < countkey; i++){		//Free the linked list "sortkey"//
		ptr = sortkey;
		sortkey=sortkey->next;
		free(ptr);
	}
	free(sortkey);
	for (i = 0; i < countval; i++){		//Free the linked list "sortval"//
		ptr = sortval;
		sortval = sortval->next;
		free(ptr);
	}
	free(sortval);
}

int init_hash(int size){		//For initialize the hashtable//
	int i;
	if (size < 1){
		printf("The size is small\nPlease eter again\n");
		return -1;
	}
	hashtable = (Dictionary*)malloc(size*sizeof(Dictionary));
	if (hashtable == NULL)
		printf("no memory\n");
	M = size;
	for (i = 0; i < M; i++){		//Initialize the key and the value with NULL//
		hashtable[i].key = NULL;
		hashtable[i].value = NULL;
	}
	return 0;
}

int insert(char* key, char* value, int(*hash)(char*, int)){		//Insert element to the hashtable//
	int index = 0, flag=0,i;
	if (key != NULL){
		index = hash(key, M);		//Get the index from hash function// 
		OccupiedZone();		//Checks if there is necessary to increase the hashtable////
		for (i = 0; i < M; i++){
			if (hashtable[index%M].key == NULL){		//If the index not occupied//
				hashtable[index%M].key = (char*)malloc((strlen(key) + 1)*sizeof(char));
				if (hashtable[index%M].key == NULL)
					printf("no memory\n");
				hashtable[index%M].value = (char*)malloc((strlen(value) + 1)*sizeof(char));
				if (hashtable[index].value == NULL)
					printf("no memory\n");
				strcpy(hashtable[index%M].key, key);
				strcpy(hashtable[index%M].value, value);
				flag = 1;
				return flag;
			}
			if ((hashtable[index%M].key != NULL)){
				index++;
			}
			else
				flag = 0;
		}
	}
	return flag;
}

int contains(char* key, int(*hash)(char*, int)){		//Function that checks if the requested key is in the hashtable//
	int  i = hash(key, M);   //Get the index from hash function// 
	while (hashtable[i%M].key != NULL){	//The loop runs untill at first null//
		if (hashtable[i].key!=NULL&&strcmp(hashtable[i].key, key) == 0){
			return 1;
		}
		i = (i + 1) % M;
	}
	return 0; 
}

char* get(char* key, int(*hash)(char*, int)){		//Function that return the value of the key//
	int  i = hash(key, M);   //Get the index from hash function// 
	while (hashtable[i%M].key != NULL){			//The loop runs untill at first null//
		if (hashtable[i].key != NULL&&strcmp(hashtable[i].key, key) == 0){
			return hashtable[i].value;
		}
		i = (i + 1) % M;
	}
	return 0;
}


int delete(char* key, int(*hash)(char*, int)){		//Function that delete element by his key//
	int  i,j=0;
	Dictionary *temp;
	if (contains(key, hash_sum) != 1){		//If the requested elemnr dosen't found//
		return 0;
	}
	M -= 1;
	temp = (Dictionary*)malloc(M*sizeof(Dictionary));		//Temp hashtable//
	for (i = 0; i < M+1; i++){
		if (hashtable[i].key != NULL){
			if (strcmp(hashtable[i].key, key) != 0){
				temp[j].key = (char*)malloc((strlen(hashtable[i].key) + 1)*sizeof(char));
				if (temp[i].key == NULL)
					printf("no memory\n");
				temp[j].value = (char*)malloc((strlen(hashtable[i].value) + 1)*sizeof(char));
				if (temp[i].value == NULL)
					printf("no memory\n");
				strcpy(temp[j].key, hashtable[i].key);
				strcpy(temp[j].value, hashtable[i].value);
				j++;
			}
		}
		else{
			temp[j].key = NULL;
			temp[j].value = NULL;
			j++;
		}
	}
	free(hashtable);
	hashtable = (Dictionary*)malloc(M*sizeof(Dictionary));		//Create a new hashtable with smaller size//
	if (hashtable == NULL)
		printf("no memory\n");
	for (i = 0; i < M; i++){
		if (temp[i].key!=NULL){
			(insert(temp[i].key, temp[i].value, hash_sum));			//New insert//
			FreeHashTable(i, temp);
		}
		if(temp[i].key==NULL){
			hashtable[i].key=NULL;
			hashtable[i].value = NULL;

		}
	}
	free(temp);
	return 1;
}

Node* get_sorted_keys(char** (*sort_function)(char** hashtableay_To_Sort, int size)){	//A function that returns a linked list of all the keys are sorted in alphabetical order//
	int i, j = 0, count = 0,tempcount=0;
	Node *list = NULL;
	for (i = 0; i < M; i++){
		if (hashtable[i].key != NULL){
			tempcount++;
		}
	}
	char **sortarr = (char**)malloc(tempcount*sizeof(char*));		//An array of strings, will be sort by alphabetical order of the keys//
	if (sortarr == NULL)
		printf("no memory\n");
	for (i = 0; i < M; i++){
		if (hashtable[i].key != NULL){
			sortarr[j] = hashtable[i].key;
			j++;
			count++;
		}
	}
	sortarr = sort_function(sortarr, count);		//Calling for sort function//
	for (i = 0; i < count; i++){
		list = addNode(list, sortarr[i]);		//Creating linked list//
	}
	free (sortarr);
	return list;
}

Node* get_sorted_values(char** (*sort_function)(char** hashtableay_To_Sort, int size)){		//A function that returns a linked list of all the values are sorted in alphabetical order//
	int i, j = 0, count = 0;
	Node *list = NULL;
	char **sortarr = (char**)malloc(M*sizeof(char*));		//An array of strings, will be sort by alphabetical order of the values//
	if (sortarr == NULL)
		printf("no memory\n");
	for (i = 0; i < M; i++){
		if (hashtable[i].value != NULL){
			sortarr[j] = hashtable[i].value;
			j++;
			count++;
		}
	}
	sortarr = sort_function(sortarr, count);		//Calling for sort function//
	for (i = 0; i < count; i++){
		list = addNode(list, sortarr[i]);		//Creating linked list//
	}
	free(sortarr);
	return list;
}


int hash_sum(char* key, int M){			//The function calculates a hash of the scheme by ASCII values ​​of each character//
	int length = strlen(key);
	int i, sum = 0;
	for (i = 0; i < length; i++)
	{
		sum += key[i];
	}
	return sum % M;
}

int hash_prime(char* key, int M){		//The function calculates the hash by ASCII values ​​schema of each character, but doubles every ASCII value of the initial number//
	int hash = 7;
	int prime = 31;
	int power = 1;
	int length = strlen(key);
	for (int i = 0; i < length; i++)
	{
		hash = hash + key[i] * power;
		power *= prime;
	}
	return hash % M;
}

void OccupiedZone(){	//If the table occupancy exceeds 75% should be increased according to table 2//
	int i, count=0;
	Dictionary *temp;
	for (i = 0; i < M; i++){		//This loop checks the indexes in the hashtable that are occupied//
		if (hashtable[i].key != NULL){
			count++;
		}
	}
	if (count!=0&& (M / count <= 100/75)){
		temp = (Dictionary*)malloc(M*sizeof(Dictionary));		//Temp hastable//
		if (temp == NULL)
			printf("no memory\n");
		for (i = 0; i < M; i++){
			if (hashtable[i].key != NULL){
				temp[i].key = (char*)malloc((strlen(hashtable[i].key) + 1)*sizeof(char));
				if (temp[i].key == NULL)
					printf("no memory\n");
				temp[i].value = (char*)malloc((strlen(hashtable[i].value) + 1)*sizeof(char));
				if (temp[i].value == NULL)
					printf("no memory\n");
				strcpy(temp[i].key, hashtable[i].key);
				strcpy(temp[i].value, hashtable[i].value);
			}
			else{
				temp[i].key = NULL;
				temp[i].value = NULL;
			}
		}
		for (i = 0; i < M; i++){
			FreeHashTable(i,hashtable);
		}
		free(hashtable);
		count = M;
		M *= 2;
		init_hash(M);		//Create hashtable with double size//
		for (i = 0; i < count; i++){
			if (temp[i].key != NULL){
				(insert(temp[i].key, temp[i].value, hash_sum));		//New insert//
				FreeHashTable(i, temp);
			}
			if (temp[i].key == NULL){
				hashtable[i].key = NULL;
				hashtable[i].value = NULL;

			}
		}
		printf("The size of the hashtable increase from %d to %d\n", count,M);
		free(temp);
	}
	if (M <= 1){
		count = M;
		M = 2;
		init_hash(M);
		printf("The size of the hashtable increase from %d to %d\n", count, M);
	}
}

void FreeHashTable(int index, Dictionary *arr){			//Free each node in the hashtable//
	free(arr[index].key);
	free(arr[index].value);
}

char** InsertionSort(char **arr, int size){		//Func of Insertion sort//
	int i,j;	
	char *key;
	for (i = 1; i < size; i++){		//This loops are for the array//
		key = arr[i];
		j = i - 1;
		while (j >= 0 && strcmp(arr[j], key) >0){		//If the key greater swap//
			arr[j + 1] = arr[j];
			j = j - 1;
		}
		arr[j + 1] = key;
	}
	return arr;
}

char** MergeSort(char **arr,int size){			//Merge sort, recursive function//
	int middle = size / 2,i;		//Middle index//
	char **left, **right;
	if (size < 2)		//If the size is two or less//
		return arr;
	left = (char**)malloc(middle*sizeof(char));
	if (left == NULL)
		printf("no memory\n");
	right = (char**)malloc((size-middle)*sizeof(char));
	if (right == NULL)
		printf("no memory\n");
	for (i = 0; i < middle; i++){
		left[i] = arr[i];		//Create left array//
	}
	for (i = middle; i < size; i++){
		right[i-middle] = arr[i];		//Create right array//
	}
	MergeSort(left, middle);		//Sorting the left array//
	MergeSort(right, (size - middle));		//Sorting the right array//
	Merge(arr, left, middle, right, size - middle);			//Merge left array and right array//
	return arr;
}

void Merge(char **arr, char **left, int cleft, char **right, int cright) {		//Merge two arrays to one//
	int i = 0, j = 0, q = 0;	//The order of the indexs: i index for the left, j index for the right and q for the merged array//
	while (i < cleft&&j < cright){				//Compare the strings of left array and right array//
		if (strcmp(left[i], right[j])  <0){		//If left need to swap//
			arr[q] = left[i];
			i++;
			q++;
		}
		else{		//If right need to swap//
			arr[q] = right[j];
			j++;
			q++;
		}
	}
	while (i < cleft){		//If one of the sides did not reach to the end//
		arr[q] = left[i];
		i++;
		q++;
	}
	while (j < cright){
		arr[q] = right[j];
		j++;
		q++;
	}
}

Node *addNode(Node *list, char* str){		//Add node to the linked list//
	Node *temp=list;
	if (list == NULL){		//If the linked list empty//
		list = (Node*)malloc(sizeof(Node));
		if (list == NULL)
			printf("no memory\n");
		list->string = str;
		list->next = NULL;
		return list;
	}
	while (temp->next != NULL){
		temp = temp->next;
	}
	temp->next = (Node*)malloc(sizeof(Node));	//Add node//
	temp = temp->next;
	temp->string= str;
	temp->next = NULL;
	return list;
}