In this work I implement a Hashtable based dictionary structure. 
The dictionary contain values (strings). 
The location of each value will be calculated according to hash function. 
The dictionary code will be generic so That the operations of the dictionary values depend on functions that are accepted as parameters. 
In order to achieve this goal, i used pointers for functions.