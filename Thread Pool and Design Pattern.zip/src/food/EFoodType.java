package food;
/*Lior Lugasi 203962006, Roy Greenberg_201559994*/
/**
 * enumeration of Food Types
 * 
 * @author baroh
 *
 */
public enum EFoodType {
	/**
	 * Meat - Most Animals
	 */
	MEAT,
	/**
	 * non food objects
	 */
	NOTFOOD,
	/**
	 * Vegetables - Most Plants
	 */
	VEGETABLE
}
