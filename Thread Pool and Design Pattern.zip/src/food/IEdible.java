package food;
/*Lior Lugasi 203962006, Roy Greenberg_201559994*/
/**
 * @author baroh
 *
 */
public interface IEdible {
	/**
	 * 
	 * @return The food type for the object
	 * @see EFoodType
	 */
	public EFoodType getFoodtype();
}
