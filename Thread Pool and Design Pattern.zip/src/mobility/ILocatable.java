package mobility;
/*Lior Lugasi 203962006, Roy Greenberg_201559994*/
import javafx.beans.Observable;

/**
 * @author baroh
 *
 */
public interface ILocatable  {
	/**
	 * @return the current location
	 */
	public Point getLocation();

	/**
	 * 
	 * @param location
	 *            the new location
	 * @return true if location is valid, false if not
	 */
	public boolean setLocation(Point location);
}
