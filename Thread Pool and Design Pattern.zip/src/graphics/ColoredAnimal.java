package graphics;
/*Lior Lugasi 203962006, Roy Greenberg_201559994*/
import animals.Animal;

public interface ColoredAnimal {
	public void PaintAnimal(String color);
	
}
