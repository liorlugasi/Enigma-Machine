Thread Pool.
Design Pattern: Singleton, Abstract Factory, 
Decorator, Observer / Listener, Prototype, Memento.