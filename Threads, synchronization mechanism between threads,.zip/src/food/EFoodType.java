/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package food;

/**
 * enumeration of Food Types
 * 
 * @author baroh
 *
 */
public enum EFoodType {
	/**
	 * Most Animals
	 */
	MEAT,
	/**
	 * non food objects
	 */
	NOTFOOD,
	/**
	 * Most Plants
	 */
	VEGETABLE
}
