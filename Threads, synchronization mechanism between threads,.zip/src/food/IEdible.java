/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package food;

/**
 * @author baroh
 *
 */
public interface IEdible {
	/**
	 * 
	 * @return The food type of the object
	 * @see EFoodType
	 */
	public EFoodType getFoodType();
}
