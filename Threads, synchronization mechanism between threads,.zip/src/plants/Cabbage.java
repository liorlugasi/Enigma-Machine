/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package plants;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import graphics.ZooPanel;

/**
 * @author baroh
 *
 */
public class Cabbage extends Plant {
	//
	/**
	 * ctor (in used)
	 * @param name
	 * @param zoo
	 */
	public Cabbage(String name,ZooPanel zoo){	
		super(name,zoo);
	}
	//

	@Override
	public void loadImages(String nm) {
		try {
			this.plant_image= ImageIO.read(new File(PATH+nm));
		} catch (IOException e) {
			this.plant_image=null;
			e.printStackTrace();
		}
		
	}

	@Override
	public void drawObject(Graphics g) {
		g.drawImage(this.getImage(),this.pan.getWidth()/2, this.pan.getHeight()/2, 50, 50, this.pan);
		
	}

	@Override
	public String getColor() {
		return "Natural";
	}
}
