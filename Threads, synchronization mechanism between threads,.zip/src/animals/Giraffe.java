/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import diet.Herbivore;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Giraffe extends AnimalThatChews {

	private double neckLength; // 1-2.5

	public Giraffe(String name, double neckLength) {
		super(name, new Point(50, 0));
		this.setWeight(450);
		this.setNeckLength(neckLength);
		this.setDiet(new Herbivore());
	}
	
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Giraffe(int size, int h_speed, int v_speed, String color,String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
		this.setWeight(this.size*2.2);
		this.setDiet(new Herbivore());

	}
	//

	@Override
	public void chew() {
		MessageUtility.logSound(this.name, "Bleats and Stomps its legs, then chews");
	}

	/**
	 * @return The length of the neck
	 */
	public double getNeckLength() {
		return neckLength;
	}

	/**
	 * @param neckLength
	 *            - new neck length
	 * @return True if assignment is successful
	 */
	public boolean setNeckLength(double neckLength) {
		if (neckLength >= 0.5 && neckLength <= 2.5) {
			this.neckLength = neckLength;
			return true;
		}
		return false;
	}
	

}
