/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import diet.Herbivore;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Turtle extends AnimalThatChews {

	private int age; // 0-500

	public Turtle(String name, int age) {
		super(name, new Point(80, 0));
		this.setWeight(1);
		this.setAge(age);
		this.setDiet(new Herbivore());
	}
	
	//
	/**
	 * ctor (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Turtle(int size, int h_speed, int v_speed, String color,String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
		this.setWeight(this.size*0.5);
		this.setDiet(new Herbivore());

	}
	//

	@Override
	protected void chew() {
		MessageUtility.logSound(this.name, "Retracts its head in then eats quietly");
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return this.age;
	}

	/**
	 * @param newAge
	 *            - the new age
	 * @return True if assignment is successful
	 */
	public boolean setAge(int newAge) {
		if (age <= 500 && age >= 0) {
			this.age = newAge;
			return true;
		}
		return false;
	}
	
	




}
