/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import diet.Herbivore;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Elephant extends AnimalThatChews {

	private double trunkLength; // 0.5 - 2.5

	public Elephant(String name, double trunkLength) {
		super(name, new Point(50, 90));
		this.setWeight(500);
		if (this.setTrunkLength(trunkLength) == false) {
			this.setTrunkLength(2);
		}
		this.setDiet(new Herbivore());
	}
	
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Elephant(int size, int h_speed, int v_speed, String color,String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
		this.setWeight(this.size*10);
		this.setDiet(new Herbivore());

	}
	//

	@Override
	public void chew() {
		MessageUtility.logSound(this.name, "Trumpets with joy while flapping its ears, then chews");
	}

	/**
	 * @return The length of the trunk
	 */
	public double getTrunkLength() {
		return trunkLength;
	}

	/**
	 * @param trunkLength
	 *            - new trunk length
	 * @return True if assignment is successful
	 */
	public boolean setTrunkLength(double trunkLength) {
		if (trunkLength >= 0.5 && trunkLength <= 2.5) {
			this.trunkLength = trunkLength;
			return true;
		}
		return false;
	}


}
