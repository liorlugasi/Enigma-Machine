/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import graphics.ZooPanel;
import mobility.Point;
/**
 * An abstract class that represent an animal that chew and extends abstract class Animal
 * @author Lior_Lugasi_203962006
 * @author Tal_Shukrun_305510273
 */
public abstract class AnimalThatChews extends Animal {

	public AnimalThatChews(String name, Point location) {
		super(name, location);
	}
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public AnimalThatChews(int size, int h_speed, int v_speed, String color, String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
	}
	//
	/**
	 * the animal chews
	 */
	protected abstract void chew();

	@Override
	public void makeSound() {
		this.chew();
	}
}
