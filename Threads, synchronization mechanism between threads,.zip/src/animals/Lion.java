/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import diet.Carnivore;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;
import utilities.Validators;

/**
 * @author baroh
 *
 */
public class Lion extends AnimalThatRoars {

	private Random rand;
	private int scarCount;

	public Lion(String name) {
		super(name, new Point(20, 0));
		this.setWeight(408.2);
		this.scarCount = 0;
		this.rand = new Random(2364624);
		this.setDiet(new Carnivore());
	}
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Lion(int size, int h_speed, int v_speed, String color,String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
		this.setWeight(this.size*0.8);
		this.setDiet(new Carnivore());
	}
	//

	/**
	 * 
	 * @see diet.Carnivore#eat
	 */
	@Override
	public boolean eat(IEdible food) {
		boolean isSuccess = super.eat(food);
		if (isSuccess && rand.nextBoolean()) {
			this.setScars(this.scarCount + 1);
		}
		return isSuccess;

	}

	@Override
	public EFoodType getFoodType() {
		return EFoodType.NOTFOOD; 
		//return super.getFoodType();
	}

	/**
	 * @return Number of scars
	 */
	public int getScars() {
		return scarCount;
	}

	@Override
	public void roar() {
		MessageUtility.logSound(this.name, "Roars, then stretches and shakes its mane");
	}

	/**
	 * @param newScarCount
	 * @return True if assignment is successful
	 */
	private boolean setScars(int newScarCount) {
		if (Validators.IsPositive(newScarCount)) {
			this.scarCount = newScarCount;
			return true;
		}
		return false;
	}
	

}
