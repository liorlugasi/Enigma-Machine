/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;

import diet.Omnivore;
import graphics.ZooPanel;
import mobility.Point;
import utilities.MessageUtility;

/**
 * @author baroh
 *
 */
public class Bear extends AnimalThatRoars {
	private final int defaultColorIndx = 0;
	private String furColor;
	private List<String> furColors = Arrays.asList("GRAY", "BLACK", "WHITE");

	public Bear(String name, String furColor) {
		super(name, new Point(100, 5));
		this.setWeight(308.2);
		if (this.setFurColor(furColor) == false) {
			this.setFurColor("GRAY");
		}
		;
		this.setDiet(new Omnivore());
	}
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Bear(int size, int h_speed, int v_speed, String color,String animal_type,ZooPanel zoo) {
		super(size,h_speed,v_speed,color,animal_type,zoo);
		this.setWeight(this.size*1.5);
		this.setDiet(new Omnivore());
	}
	//

	/**
	 * @return Fur color
	 */
	public String getFurColor() {
		return furColor;
	}

	@Override
	public void roar() {
		MessageUtility.logSound(this.name, "Stands on its hind legs, roars and scratches its belly");
	}

	/**
	 * @param newFurColor
	 *            - The new fur color
	 * @return True if assignment is successful
	 */
	public boolean setFurColor(String newFurColor) {

		if (furColors.contains(newFurColor)) {
			this.furColor = newFurColor;
			return true;
		}
		this.furColor = furColors.get(defaultColorIndx);
		return false;
	}
	


}
