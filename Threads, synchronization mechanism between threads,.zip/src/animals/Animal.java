/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package animals;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import diet.IDiet;
import food.EFoodType;
import food.IEdible;
import graphics.IAnimalBehavior;
import graphics.IDrawable;
import graphics.ZooPanel;
import mobility.Mobile;
import mobility.Point;

/**
 * 
 * @author baroh
 * @author Lior_Lugasi_203962006
 * @author Tal_Shukrun_305510273
 *
 */
public abstract class Animal extends Mobile implements IEdible ,IDrawable,IAnimalBehavior,Runnable {

	/**
	 * Weight loss factor after moving
	 */
	public static final double WEIGHT_LOSS_FACTOR = 0.00025;

	private IDiet diet;
	protected String name;
	private double weight;
	protected final int EAT_DISTANCE = 10;
	protected int size;
	protected Color col;
	protected int horSpeed;
	protected int verSpeed;
	protected boolean coordChanged;
	protected Thread thread;
	protected int x_dir;
	protected int y_dir;
	protected int eatCount;
	protected ZooPanel pan;
	protected boolean threadSuspended;	 
	protected BufferedImage img1, img2;
	
	//
	protected volatile boolean state;
	protected String animal_type;
	protected int temp_dirx;
	protected int temp_diry;
	protected final String END=".png";
	protected boolean isThreadAlive;
	private int old_x,old_y;
	
	

	public Animal(String name, Point location) {
		super(location);
		this.setName(name);
		this.setNewLocation(location);
	}
	//
	/**
	 * ctor  (in used)
	 * @param size
	 * @param h_speed
	 * @param v_speed
	 * @param color
	 * @param animal_type
	 * @param zoo
	 */
	public Animal(int size,int h_speed,int v_speed,String color,String animal_type,ZooPanel zoo){
		super(size,h_speed,v_speed,color);
		this.pan=zoo;
		this.name=animal_type;
		this.size=size;
		this.col=ToColor(color);
		this.horSpeed=h_speed;
		this.verSpeed=v_speed;
		this.isThreadAlive=true;
		this.x_dir=1;
		this.y_dir=1;
		this.state=false;
		this.setNewLocation(new Point(0,0));
		this.threadSuspended=false;
		this.thread=new Thread(this);
		this.ConvertTypeToImage(this.name);
		old_x=this.location.getX();
		old_y=this.location.getY();
		
	}

	/**
	 * The animal eats the food and gains weight
	 * 
	 * @param food
	 *            - Food to eat
	 * @return True if food was eaten
	 */
	public boolean eat(IEdible food) {
		double gainedWeight = this.diet.eat(this.weight, food);
		if (gainedWeight > 0) {
			this.weight += gainedWeight;
			this.makeSound();
			return true;
		}
		return false;
	}

	/**
	 * @return the diet
	 */
	public IDiet getDiet() {
		return this.diet;
	}

	@Override
	public EFoodType getFoodType() {
		return EFoodType.MEAT;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @return the weight
	 */
	public double getWeight() {
		return this.weight;
	}

	/**
	 * makes a sound
	 */
	public abstract void makeSound();

	@Override
	public double move(Point newLocation) {
		double distance = super.move(newLocation);
		if (distance > 0) {
			this.setWeight(this.weight - (distance * this.weight * WEIGHT_LOSS_FACTOR));
		}
		return distance;
	}

	/**
	 * @param newDiet
	 */
	protected void setDiet(IDiet newDiet) {
		this.diet = newDiet;
	}

	/**
	 * 
	 * @param newName
	 *            - The new name
	 * @return True if assignment is successful
	 */
	public boolean setName(String newName) {
		if (newName.isEmpty() || newName == null) {
			return false;
		}
		this.name = newName;
		return true;
	}

	/**
	 * @param newWeight
	 *            - The new weight
	 * @return True if assignment is successful
	 */
	public boolean setWeight(double newWeight) {
		if (utilities.Validators.IsPositive(newWeight)) {
			this.weight = newWeight;
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "[" + this.getClass().getSimpleName() + "] " + this.name;
	}
	
	/**
	 * 
	 * @param color
	 * Function that get variable from type String and return variable from type Color
	 * @return  variable from type Color
	 */
	private Color ToColor(String color) {
		switch(color){
		case "Red":{
			return Color.RED;
		}
		case "Blue":{
			return Color.BLUE;
		}
		case "Natural":{
			return null;
		}
		default:{
			return null;
		}
		}
	}
	
	/**
	 * 
	 * @param type
	 *  operate the function loadImages by the message it gets
	 */
	public void ConvertTypeToImage(String type){
		switch(type){
		case "Lion":{
			this.loadImages("lio_");
			break;
		}
		case "Bear":{
			this.loadImages("bea_");
			break;
		}
		case "Elephant":{
			this.loadImages("elf_");
			break;
		}
		case "Giraffe":{
			this.loadImages("grf_");
			break;
		}
		case "Turtle":{
			this.loadImages("trt_");
			break;
		}
		}
	}
	
	/**
	 * by synchronized the threads the following function operate the animal's actions - move, food, sleep, dying
	 */
	public void run() {
		int tempx=this.verSpeed,tempy=this.horSpeed;
		while(isThreadAlive){
		
			if(this.threadSuspended)
			{
				synchronized(this)
				{
				try {
					this.setChanges(false);
					wait();		//Sleep
				} catch (InterruptedException e)
				{
					System.out.println(this.name+" is Dead");
					this.setIsThreadAlive(false);	
				}
				}
			}
			if (this.pan.getIsFood()&&this.diet.canEat(this.pan.getCurrentFood())){
				this.FoodDirection();
				this.verSpeed=tempx;
				this.horSpeed=tempy;
			}
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				System.out.println(this.name+" is Dead");
				this.threadSuspended=true;	
			}
			
			location.setX(location.getX() + horSpeed*x_dir);
			location.setY(location.getY() + verSpeed*y_dir);
		
			if(location.getX() > pan.getWidth()-size/4)
				x_dir = -1;
			else if(location.getX() < - size*0.25)
				x_dir = 1;
			if(location.getY() > (int) (pan.getHeight()-30 - size*9/10))
				y_dir = -1;
			else if(location.getY() < size/10)
				y_dir = 1;
			if(location.getX()!=old_x||location.getY()!=old_y)
				this.setChanges(true);
			else
				this.setChanges(false);

			
		}
	}
	
	
	/**
	 * Drawing the animals by the correct pictures
	 */
	public void drawObject (Graphics g)
	{
		g.setColor(col);
		if(x_dir==1) // animal goes to the right side
			g.drawImage(img1, location.getX(), location.getY()-size/10, size/2, size, pan);
		else // animal goes to the left side
			g.drawImage(img2, location.getX(), location.getY()-size/10, size/2, size, pan);
	}
	
	//
	
	/**
	 * Directs the animals toward the food
	 */
	public void FoodDirection(){
		double v_new=0,v_old=0,v_hor_new=0,v_ver_new=0,k=0;
		int flag=0;
			
				while(this.pan.getIsFood())
				{
					
					
					
					try 
					{
					Thread.sleep(20);
					
					} 
					catch (InterruptedException e) 
					{
						e.printStackTrace();
					}
					v_old = Math.sqrt((horSpeed*horSpeed) + (verSpeed*verSpeed));  				
					v_new = v_old;
					double z = (location.getX() - this.pan.getWidth()/2);
					if (z == 0)
						z = 1;
					k = Math.abs( (location.getY() - this.pan.getHeight()/2) / z );
					v_hor_new = v_new / Math.sqrt(k*k+1);
					v_ver_new = v_hor_new * k ;
					if(location.getX() > this.pan.getWidth() / 2)
						x_dir = -1;
					else
						x_dir = 1;
					if(location.getY() >this.pan.getHeight() / 2)
						flag = -1;
					else
						flag = 1;
					location.setX(location.getX() +(int)v_hor_new * x_dir) ;
					location.setY(location.getY()+(int)v_ver_new * flag);
					
					if(location.getX()!=old_x||location.getY()!=old_y)
						this.setChanges(true);
					else
						this.setChanges(false);
					
					synchronized(this.pan.Lock())
					{
					if(Math.abs(location.getX() - this.pan.getWidth()/2) <= EAT_DISTANCE && Math.abs(location.getY() - this.pan.getHeight()/2) <= EAT_DISTANCE)
					{
						if (this.pan.getCurrentFood()==EFoodType.MEAT)
							this.weight+=this.diet.eat(this.weight,this.pan.getMeat());	//change the weight
						if (this.pan.getCurrentFood()==EFoodType.VEGETABLE)
							this.weight+=this.diet.eat(this.weight,this.pan.getPlant());	//change the weight
						this.size=(int) (this.weight/this.pan.getHashtable(this.name));		//change the size
						this.pan.CallBack(this);
						this.pan.setIsFood(false);	
						y_dir=flag;
						this.setChanges(true);
					}	
					}
				}
	}

	
	
	/**
	 * 
	 * @param color
	 * @return every picture has a string that determine the animals color(bea_b_1 - blue) - this function return the color  
	 */
	public String ConvertColorToImage(String color){
		switch(color){
		case "Red":{
			return "r";
		}
		case "Blue":{
			return "b";
		}
		case "Natural":{
			return "n";
		}
		default:{
			return null;
		}
		}
	}
	
	/**
	 * start the thread
	 */
	public void Start(){
		this.thread.start();
	}
	/**
	 * kill th thread
	 */
	public synchronized void KillThread(){
		this.thread.interrupt();
	}
	
	/**
	 * 
	 * @return the variable that state if the animal is in suspended
	 */
	public boolean getThreadSuspended() {
		return this.threadSuspended;
	}
	
	/**
	 * 
	 * @return the variable that check if the thread is alive
	 */
	public boolean getIsThreadAlive(){
		return this.isThreadAlive;
	}
	
	/**
	 * 
	 * @param isrun
	 * @return true if the Placement succeed
	 */
	public boolean setIsThreadAlive(boolean isrun){
		this.isThreadAlive=isrun;
		return true;
	}
	

	
	/**
	 * 
	 * @return the horizontal speed
	 */
	public int getHorSpeed(){
		return this.horSpeed;
	}
	/**
	 * 
	 * @return the vertical speed
	 */
	public int getVerSpeed(){
		return this.verSpeed;
	}
	
	/**
	 * 
	 * @param size
	 * @return true if the placement succeed
	 */
	public boolean setSize(int size){
		if(size>=0){
			this.size=size;
			return true;
		}
		return false;
	}
	
	/**
	 * load the images (for right and left movement)
	 */
	@Override
	public void loadImages(String nm) {
		this.animal_type=nm+ConvertColorToImage(this.getColor());
		try {
			img1 = ImageIO.read(new File(PICTURE_PATH+this.animal_type+"_1"+END)); } 
		catch (IOException e) {
			System.out.println("Cannot load image"); }
		try {
			img2 = ImageIO.read(new File(PICTURE_PATH+this.animal_type+"_2"+END)); } 
		catch (IOException e) {
			System.out.println("Cannot load image"); }
		
	}
	
	/**
	 * return the color of the animal
	 */
	@Override
	public String getColor() {
		if (this.col==Color.RED)
			return "Red";
		if(this.col==Color.BLUE)
			return "Blue";
		return "Natural";
	}
	
	/**
	 * return the animal's name(type)
	 */
	@Override
	public String getAnimalName() {
		return this.name;
	}
	/**
	 * return the animal's size
	 */
	@Override
	public int getSize() {
		return this.size;
	}
	/**
	 * Updating the number of times the animal has eaten 
	 */
	@Override
	public void eatInc() {
		this.eatCount++;
		
	}
	/**
	 * return the number of times the animal has eaten
	 */
	@Override
	public int getEatCount() {
		
		return this.eatCount;
	}
	/**
	 * updating the state of the animal location
	 */
	@Override
	public synchronized boolean getChanges() {
		return this.state;
	}
	/**
	 * Change the variable threadSuspended to true (the thread is suspended)
	 */
	@Override
	public void setSuspended() {
		this.threadSuspended=true;
		
	}
	/**
	 * Change the variable threadSuspended to false (the thread is running)
	 */
	@Override
	public void setResumed() {
		this.threadSuspended=false;
		
	}
	/**
	 * change the state of the animal (if ther's change in the location)
	 */
	@Override
	public synchronized void setChanges(boolean state) {
		this.state=state;
		
	}
	
	
	
}
