/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package graphics;

import java.awt.BorderLayout;
import animals.Animal;
import animals.Bear;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;
import diet.Carnivore;
import diet.Herbivore;
import diet.Omnivore;
import food.EFoodType;
import food.IEdible;
import plants.Cabbage;
import plants.Lettuce;
import plants.Plant;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 * A class that represent a panel on the frame
 * @author Lior Lugasi_203962006
 * @author Tal_Shukrun_305510273
 *
 */
public class ZooPanel extends JPanel implements Runnable, ActionListener {
	private JPanel down_panel;
	private JButton [] buttons;
	private ZooFrame p_frame;
	private String [] buttonsName={"Add Animal","Sleep","Wake Up","Clear","Food","Info","Exit"};
	private String [] columnames = {"Animal","Color","Weight","Hor.speed","Ver.speed","Eat counter"};
	private ArrayList<Animal> animals;
	private static JTable infotable;
	private static JPanel tablePanel=new JPanel();
	private int total_eat;
	private boolean isClicked;
	private boolean isFood;
	private final int MEAT=0;
	private final int CABBAGE=1;
	private final int LETTUCE=2;
	private String what_veg_food;
	private Plant plant;
	private EFoodType Food;			//meat
	private String [] animalsname={"Lion","Bear","Elephant","Giraffe","Turtle"};  //keys in dictionary
	private Double [] animal_weight_gain={0.8,1.5,10.0,2.2,0.5};  //values in dictionary that includes the calculates of weight gain of the animals//
	private static EFoodType currentFood;
	private static Object mutex=new Object();
	private Hashtable<String,Double> dict;
	private Thread controller;
	private Meat meat1;
	
	/**
	 * A constructor that updates all class variables
	 * @param frame
	 */
	public ZooPanel(ZooFrame frame){
		down_panel=new JPanel(new GridLayout(0,7));
		this.animals=new ArrayList<Animal>();
		controller=new Thread(this);
		controller.start();
		p_frame=frame;
		Food=null;
		this.what_veg_food=null;
		new JPanel(new BorderLayout());
		dict=new Hashtable<String,Double>();
		for (int i = 0; i < animal_weight_gain.length; i++)  //initialize the dict
		{
			this.dict.put(animalsname[i], animal_weight_gain[i]);
		}
		total_eat=0;
		infotable=new JTable();
		this.isClicked=false;
		this.isFood=false;
		this.plant=null;
		this.meat1=null;
		buttons=new JButton[7];
		for(int i=0;i<buttons.length;i++){
			buttons[i]=new JButton(buttonsName[i]);
			buttons[i].addActionListener(this); 
			down_panel.add(buttons[i]);     //Add buttons to down panel//
		}
		this.setBackground(Color.WHITE);
	}
	
	/**
	 * function that returns the variable mutex (for synchronized) 
	 * @return the variable mutex (for synchronized) 
	 */
	public Object Lock(){		//getMutex
		return mutex;
	}
	

	/**
	 * 
	 * @return the down panel
	 */
	public JPanel getDown_Panel(){
		return this.down_panel;
	}
	/**
	 * 
	 * @return the button for down panel
	 */
	public JButton[] getButtons(){
		return buttons;
	}
	
	/**
	 * 
	 * @return the current food (meat or vegetable)
	 */
	public EFoodType getCurrentFood(){
		return currentFood;
	}
	
	/**
	 * 
	 * @param key
	 * @return values in dictionary that includes the calculates of weight gain of the animals
	 */
	public double getHashtable(String key){
		return this.dict.get(key);
	}
	
	/**
	 * 
	 * @return variable from type Meat
	 */
	public Meat getMeat(){
		return this.meat1;
	}
	
	/**
	 * 
	 * @return variable from type Plant
	 */
	public Plant getPlant(){
		return this.plant;
	}
	
	/**
	 * by synchronized the threads the following function operate the actions
	 */
	@Override
	public void run() {		//Controller
		while(true){
			
			synchronized(mutex){
			
			if(!animals.isEmpty())
			for (Animal a :animals){

				if (a.getDiet() instanceof Carnivore||a.getDiet() instanceof Omnivore){
					if(this.AnimalEatAnimal(a)){
						repaint();
						break;
					}
				}
				if(a.getChanges())
					this.repaint();
				
				}
			}
			}
		}
	/**
	 * updating the animal number of eating and total et of all animals
	 * @param a
	 */
	public void CallBack(Animal a){
		a.eatInc();
		this.total_eat++;
	}
	/**
	 * function that operate the eating of animal by another animal according to the terms
	 * @param a
	 * @return true if the animal eat another animal
	 */
	public boolean AnimalEatAnimal(Animal a){
		for( Animal pray : animals){
			if(a!=pray)
			if (pray.getDiet() instanceof Omnivore||pray.getDiet() instanceof Herbivore){
				if(a.getLocation().getX() - pray.getLocation().getX() <= pray.getSize() && a.getLocation().getY() - pray.getLocation().getY() <= pray.getSize())
				{
					if(a.getDiet().canEat(pray.getFoodType()))
					{
						if(a.getWeight()>=2*pray.getWeight()){
							
							
							a.setWeight(a.getWeight()+a.getDiet().eat(a.getWeight(),pray));
							a.setSize((int) (a.getWeight()/this.getHashtable(a.getName())));
							a.eatInc();		//eat_counter++
							this.total_eat++;	//total_eat++
							pray.KillThread();//calling for function that calls to interupt function
							animals.remove(pray);
							return true;
						}
					}
				}
			}
		
		}
		return false;
	}
	/**
	 * 
	 * @return total eat of all animals
	 */
	public int getTotalEat(){
		return this.total_eat;
	}
	
	/**
	 * 
	 * @return true if the updating succeed
	 */
	public boolean setTotalEat(){
		this.total_eat++;
		return true;
	}

	/**
	 * function that operate the down panel buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==buttons[0]){		//Add Animal//
			if (this.animals.size()<10){
				AddAnimalDialog temp=new AddAnimalDialog();
				if (temp.success){
					Animal a=this.FactoryMethod(temp);
					if (a!=null){
						synchronized(mutex){
							animals.add(a);
						}
						
						a.Start();
					}
				}
			}
			else
				JOptionPane.showMessageDialog(this, "You cannot add more then 10 animals");
		}
		if (e.getSource()==buttons[1]){	    //Sleep//
			for(Animal a: animals){
				if(a.getThreadSuspended()==false)
					a.setSuspended();
			}
				
		}
		if	(e.getSource()==buttons[2]){	//Wake Up//
			for(Animal a: animals){
				if(a.getThreadSuspended()==true){
					a.setResumed();	
					synchronized(a){
					a.notify();
					}
				}	
			}
		}
		if	(e.getSource()==buttons[3]){	//Clear//
			synchronized(mutex){
			for(Animal a:animals){
				if (a.getIsThreadAlive()==true){
					a.KillThread();
				}
			}
			animals.removeAll(animals);
			this.total_eat=0;
			if (isFood){
				this.Food=null;
				this.plant=null;
				this.isFood=false;
			}
				
			this.repaint();
		}
		}
		if (e.getSource()==buttons[4]){		//Food//
			
			if(animals.size()>0){
				if (this.isFood==false){	
					int choice=JOptionPane.showOptionDialog(p_frame, "Please choose food", "Food for animals",JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[]{"Meat","Cabbage","Lettuce"}, "Meat");
					switch(choice){
					case MEAT:{
						Food=EFoodType.MEAT;
						meat1=new Meat("meat",this);
						break;
					}
					case CABBAGE:{
						plant=new Cabbage("Cabbage",this);
						this.what_veg_food="Cabbage";
						break;
					}
					case LETTUCE:{
						plant=new Lettuce("Lettuce",this);
						this.what_veg_food="Lettuce";
						break;
					}
					default :{JOptionPane.showMessageDialog(p_frame,"ERROR");
					break;
					}
					}
					this.isFood=true;
					currentFood=Food==null?EFoodType.VEGETABLE:EFoodType.MEAT;
				}
				else{
					JOptionPane.showMessageDialog(p_frame,"There's already food");	
				}
			}else{
				JOptionPane.showMessageDialog(p_frame,"There are not animals!");	
			}
		}
		if (e.getSource()==buttons[5]){		//Info//
			if(animals.size()>0){
				this.setTable();
				add(tablePanel);
				this.updateUI();
			}
			else{
				JOptionPane.showMessageDialog(this, "There are no animals to show");
			}
			
		}
		if	(e.getSource()==buttons[6]){	//Exit//
			System.exit(0);
		}
	}
	/**
	 * @return boolean variable that determined if there's food
	 */
	public boolean getIsFood(){
		return this.isFood;
	}
	
	/**
	 * 
	 * @param bool
	 * @return true if the placement action succeed
	 */
	public boolean setIsFood(boolean bool){
		this.isFood=bool;
		if(bool==false){
			this.Food=null;
			this.plant=null;
		}
			
		return true;
	}
	
	/**
	 * function that calls for drawObject method in the different classes for painting the chosen object
	 */
	public void paintComponent(Graphics g){
		super.paintComponent(g);
	
		if (p_frame.getIsImage()){
			g.drawImage(p_frame.getBg(),0,0, this.getWidth(), this.getHeight(), this);
		}
		if(isFood==true){
			if(Food!=null){
				meat1=new Meat("Meat",this);
				meat1.drawObject(g);

			}
			else{
				if(this.what_veg_food=="Lettuce"){
					Lettuce let=new Lettuce("Lettuce",this);
					let.drawObject(g);
				}
				if(this.what_veg_food=="Cabbage"){
					Cabbage ceb=new Cabbage("Cabbage",this);
					ceb.drawObject(g);
				}
			}
		}
		for(Animal a:animals){
			a.drawObject(g);
		}
	}
	
	/**
	 * create new animal according to the chosen type
	 * @param animal
	 * @return object type Animal
	 */
	private Animal FactoryMethod(AddAnimalDialog animal){
		switch(animal.getAnimal_type()){
		case "Lion":
		{
			return new Lion(animal.getAnimalSize(),animal.getHorizontal_speed(),animal.getVertical_speed(),animal.getAnimal_color(), "Lion",this);
		}
		case "Bear":
		{
			return new Bear(animal.getAnimalSize(),animal.getHorizontal_speed(),animal.getVertical_speed(),animal.getAnimal_color(), "Bear",this);
		}
		case "Elephant":
		{
			return new Elephant(animal.getAnimalSize(),animal.getHorizontal_speed(),animal.getVertical_speed(),animal.getAnimal_color(), "Elephant",this);
		}
		case "Giraffe":
		{
			return new Giraffe(animal.getAnimalSize(),animal.getHorizontal_speed(),animal.getVertical_speed(),animal.getAnimal_color(), "Giraffe",this);
		}
		case "Turtle":
		{
			return new Turtle(animal.getAnimalSize(),animal.getHorizontal_speed(),animal.getVertical_speed(),animal.getAnimal_color(), "Turtle",this);
		}
		}
		return null;
	}
	
	/**
	 * create the table for option info
	 */
	public void setTable(){
		if(!isClicked){
			DefaultTableModel dtm = new DefaultTableModel(0,0);
			dtm.setColumnIdentifiers(columnames);    
			infotable.setModel(dtm);
			for (Animal a : animals) {
				dtm.addRow(new Object[] { a.getAnimalName(), a.getColor(),a.getWeight(),a.getHorSpeed(),a.getVerSpeed(),a.getEatCount()});
			}
			dtm.addRow(new Object[] { "Total","","","","",total_eat});
			infotable.setFillsViewportHeight(true);
			infotable.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			JScrollPane tableContainer = new JScrollPane(infotable);
			tablePanel.add(tableContainer);
			tablePanel.setVisible(true);
		}
		else
			tablePanel.setVisible(false);
		this.isClicked=!this.isClicked;
	}
}
