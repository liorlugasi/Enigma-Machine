/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package graphics;

import java.awt.Graphics;

public interface IDrawable {
	public final static String PICTURE_PATH = "C:/Users/ron16/Desktop/pictures/";
	public void loadImages(String nm);
	public void drawObject (Graphics g);
	public String getColor();
}
