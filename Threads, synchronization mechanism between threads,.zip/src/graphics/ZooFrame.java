/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package graphics;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 * A class that represent a frame
 * @author Lior Lugasi_203962006
 * @author Tal_Shukrun_305510273
 *
 */
public class ZooFrame extends JFrame implements ActionListener    {
	private JFrame frame;
	private JMenu file,help,background;
	private JMenuBar menu;
	private JMenuItem []items;
	private static ZooFrame zoo;
	private ZooPanel main_panel;
	private JFileChooser choose;
	private int value;
	private boolean isImage;
	private Image bg;
	
	/**
	 * A constructor that updates all class variables
	 */
	public ZooFrame(){
		frame=new JFrame("Zoo");
		main_panel=new ZooPanel(this);
		frame.setJMenuBar(BuildMenuBar());
		this.isImage=false;
		frame.add(main_panel);
		frame.add(main_panel.getDown_Panel(),BorderLayout.SOUTH);
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setVisible(true);
		choose =new JFileChooser();


		
	}
	
	/**
	 * main function, create the frame
	 * @param args
	 */
	public static void main(String[] args){
		zoo=new ZooFrame();
	}

	/**
	 * function that operate the top panel/menu
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==items[0]){	//Exit//
			System.exit(0);
		}
		if(e.getSource()==items[1]){	//Image//
			value=choose.showOpenDialog(null);
			if(value==choose.APPROVE_OPTION){
		
				File file=choose.getSelectedFile();
				try {
					bg=getScaledImage(ImageIO.read(file));
					isImage=true;
					main_panel.repaint();
             
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
				
			}
		}
		if(e.getSource()==items[2]){	//Green//
			if(this.isImage){
				this.isImage=false;
				main_panel.repaint();
			}
			main_panel.setBackground(Color.GREEN);
		}
		if(e.getSource()==items[3]){		//None
			if(this.isImage){
				this.isImage=false;
				main_panel.repaint();
			}
			main_panel.setBackground(null);
		}
		if(e.getSource()==items[4]){		//Help//
			JOptionPane.showMessageDialog(this,"Home Work 3\nGUI @ Threads" );
		}
		
		
	}
	
	/**
	 * build the top menu
	 * @return the top menu
	 */
	public JMenuBar BuildMenuBar(){
		file=new JMenu("File");
		help=new JMenu("Help");
		background=new JMenu("Background");
		items=new JMenuItem[5];
		String []itemsName={"Exit","Image","Green","None","Help"};
		for(int i=0;i<items.length;i++){
			items[i]=new JMenuItem(itemsName[i]);
			items[i].addActionListener(this);
		}
		file.add(items[0]);
		for(int i=1;i<4;i++){
			background.add(items[i]);
		}
		help.add(items[4]);
		menu=new JMenuBar();
		menu.add(file);
		menu.add(background);
		menu.add(help);
		return menu;
	}
	
	/**
	 * suit the image to the main panel
	 * @param srcImg
	 * @return object from type Image
	 */
	private Image getScaledImage(Image srcImg){
		Image dimg =  srcImg.getScaledInstance(main_panel.getWidth(), main_panel.getHeight()+10,Image.SCALE_SMOOTH);
		return dimg;
	}
	
	/**
	 * 
	 * @return true if there's image
	 */
	public boolean getIsImage() {
		return isImage;
	}
	
	/**
	 * 
	 * @return the image after suit in function getScaledImage
	 */
	public Image getBg() {
		return bg;
	}

	
}
