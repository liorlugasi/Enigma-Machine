/*Lior Lugasi 203962006, Tal Shukrun 305510273*/

package graphics;

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.ILocatable;
import mobility.Point;
import utilities.MessageUtility;
import utilities.Validators;

/**
 * Represents a Meat
 * 
 * @author Lior Lugasi_203962006
 * @author Tal_Shukrun_305510273
 * 
 */
public class Meat implements IEdible, ILocatable,IDrawable {

	private double height;
	private Point location;
	private double weight;
	
	//
	private Image meat_image;
	private String name;
	private ZooPanel pan;
	//
	public Meat() {
		Random rand = new Random();
		int x = rand.nextInt(30);
		int y = rand.nextInt(12);
		this.location = new Point(x, y);
		this.height = rand.nextInt(30);
		this.weight = rand.nextInt(12);
		MessageUtility.logConstractor("Plant", "Plant");
	}
	
	//
	/**
	 * A constructor (in used)
	 * @param name
	 * @param zoo
	 */
	public Meat(String name,ZooPanel zoo){
		this.location=new Point(zoo.getWidth(),zoo.getHeight());
		this.pan=zoo;
		this.name=name;
		this.loadImages("meat.gif");
	}
	
	//Getters//
	/**
	 * 
	 * @return the image of the meat
	 */
	public Image getImage(){
		return this.meat_image;
	}
	//
	/**
	 * @return the food type
	 */
	@Override
	public EFoodType getFoodType() {
		MessageUtility.logGetter(this.getClass().getSimpleName(), "getFoodType", EFoodType.MEAT);
		return EFoodType.MEAT;
	}

	/**
	 * @return The height of the meat
	 */
	public double getHeight() {
		MessageUtility.logGetter(this.getClass().getSimpleName(), "getHeight", this.height);
		return this.height;
	}
	
	/**
	 * @return the location
	 */
	@Override
	public Point getLocation() {
		MessageUtility.logGetter(this.getClass().getSimpleName(), "getLocation", this.location);
		return this.location;
	}

	/**
	 * @return The weight of the meat
	 */
	public double getWeight() {
		MessageUtility.logGetter(this.getClass().getSimpleName(), "getWeight", this.weight);
		return weight;
	}
	
	/**
	 * return the color of the meat
	 */
	@Override
	public String getColor() {
		return "Natural";
	}
	
	//Setters//
	/**
	 * @param newHeight - the new height
	 * @return True if assignment is successful
	 */
	public boolean setHeight(double newHeight) {

		if (Validators.IsPositive(newHeight)) {
			this.height = newHeight;
			return true;
		}
		this.height = 0;

		return false;
	}

	@Override
	public boolean setNewLocation(Point newLocation) {
		if (Point.checkBoundaries(newLocation)) {
			this.location = new Point(newLocation);
			return true;
		}

		this.location = new Point(0, 0);
		return false;
	}

	/**
	 * @param newWeight - the new weight
	 * @return True if assignment is successful
	 */
	public boolean setWeight(double newWeight) {

		if (Validators.IsPositive(newWeight)) {
			this.weight = newWeight;
			return true;
		}
		this.weight = 0;

		return false;
	}

	@Override
	public String toString() {
		return "[" + this.getClass().getSimpleName() + "] ";
	}
	
	/**
	 * load the image
	 */
	@Override
	public void loadImages(String nm) {
		try {
			this.meat_image= ImageIO.read(new File(PICTURE_PATH+nm));
		} catch (IOException e) {
			this.meat_image=null;
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Drawing the meat by the correct picture
	 */
	@Override
	public void drawObject(Graphics g) {
		g.drawImage(this.getImage(),this.pan.getWidth()/2, this.pan.getHeight()/2, 50, 50, this.pan);
		
	}
	


}
