/*Lior Lugasi 203962006, Tal Shukrun 305510273*/


package graphics;

import java.awt.Color;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 * A class for creating a dialog window
 * @author Lior_Lugasi_203962006
 * @author Tal_Shukrun_305510273
 *
 */
public class AddAnimalDialog extends JDialog  {
	private String animal_type;
	private int animal_size;
	private int horizontal_speed;
	private int vertical_speed;
	private String animal_color;
	public boolean success;
	
	/**
	 * A constructor that build and show options for the user
	 */
	public AddAnimalDialog(){
		Object []sizes={"1","2","3","4","5","6","7","8","9","10"};
		Object [] animals={"Lion","Bear","Elephant","Giraffe","Turtle"};
		Object [] colors={"Red","Natural","Blue"};
		this.animal_type=(String)JOptionPane.showInputDialog( null,"Choose animal type: ","",JOptionPane.PLAIN_MESSAGE,null,animals,"Lion");
		if(animal_type==null){
			success=false;
			return;
		}
		do{
		String tempsize=JOptionPane.showInputDialog(null,"Choose the "+animal_type+" size (between 50-300): ");
		if(tempsize.length()==0||!tempsize.matches("[0-9]+")||tempsize.startsWith("0")){
			JOptionPane.showMessageDialog(this, "You haven't choose the "+animal_type+" size (between 50-300)");
			success=false;
			return;
		}
		this.animal_size=Integer.parseInt(tempsize);
		}while(animal_size<50||animal_size>300);
		String temp=(String)JOptionPane.showInputDialog( null,"Choose the "+animal_type+" horizontal speed: ","",JOptionPane.PLAIN_MESSAGE,null,sizes,"1");
		if(temp==null){
			success=false;
			return;
		}
		this.horizontal_speed=Integer.parseInt(temp);
		temp=(String)JOptionPane.showInputDialog( null,"Choose the "+animal_type+" vertical speed: ","",JOptionPane.PLAIN_MESSAGE,null,sizes,"1");
		if(temp==null){
			success=false;
			return;
		}
		this.vertical_speed=Integer.parseInt(temp);
		this.animal_color=(String)JOptionPane.showInputDialog( null,"Choose the "+animal_type+" color: ","",JOptionPane.PLAIN_MESSAGE,null,colors,"Natural");
		if(animal_type==null){
			success=false;
			return;
		}
		success=true;
		
	}
	
	//Getters//
	/**
	 * return the animal type
	 * @return
	 */
	public String getAnimal_type() {
		return animal_type;
	}

	/**
	 * 
	 * @return the animal's size
	 */
	public int getAnimalSize() {
		return animal_size;
	}

	/**
	 * 
	 * @return the horizontal speed of the animal
	 */
	public int getHorizontal_speed() {
		return horizontal_speed;
	}
	

	/**
	 * 
	 * @return the vertical speed of the animal
	 */
	public int getVertical_speed() {
		return vertical_speed;
	}
	

	/**
	 * 
	 * @return the animal color
	 */
	public String getAnimal_color() {
		return animal_color;
	}
	/**
	 * 
	 * @param animal_color
	 * @return true if the placement action succeed
	 */
	public boolean setAnimal_color(String animal_color)
	{
		if(animal_color!=null){
			this.animal_color = animal_color;
			return true;
		}
		return false;
	}	
	
	//Setters//
	/**
	 * 
	 * @param animal_type
	 * @return true if the placement action succeed
	 */
	public boolean setAnimal_type(String animal_type) {
		if(animal_type!=null){
			this.animal_type = animal_type;
			return true;
		}
		return false;
	}
	

	
	/**
	 * 
	 * @param horizontal_speed
	 * @return true if the placement action succeed
	 */
	public boolean setHorizontal_speed(int horizontal_speed)
	{
		if(horizontal_speed>=0)
		{
			this.horizontal_speed = horizontal_speed;
			return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @param vertical_speed
	 * @return true if the placement action succeed
	 */
	public boolean setVertical_speed(int vertical_speed)
	{
		if(vertical_speed>=0)
		{
			this.vertical_speed = vertical_speed;
			return true;
		}
			return false;
	}
	
	/**
	 * 
	 * @param size
	 * @return true if the placement action succeed
	 */
	public boolean setAnimalSize(int size) {
		if(size>=0){
			this.animal_size = size;
			return true;
		}
		return false;
			
	}
}
