The project includes:
� Build and run threads in Java.
� Developing a synchronization mechanism between threads.
� Using MVC principles to construct a GUI environment.
Work must be performed according to the requirements specified in the
given document. In this work, you must implement the GUI 
interface for managing the zoo by using the defined actions.