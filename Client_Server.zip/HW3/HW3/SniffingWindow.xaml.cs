﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HW3
{
    /// <summary>
    /// Interaction logic for SniffingWindow.xaml
    /// for Question 1
    /// </summary>
    public partial class SniffingWindow : Window
    {
        /// <summary>
        /// List of sniffers that listens to any IP
        /// </summary>
        static List<Sniffer> Snf { get; set; }

        /// <summary>
        /// Ctor
        /// </summary>
        public SniffingWindow()
        {
            InitializeComponent();
            Snf = new List<Sniffer>();
            IPAddress[] hosts = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
            for (int i = 0; i < hosts.Length; i++)
            {
                Sniffer sniffer = new Sniffer(hosts[i]);
                sniffer.newPacketEventHandler += new Sniffer.NewPacketEventHandler(onNewPacket);
                Snf.Add(sniffer);
                sniffer.start();
            }
            
        }

        /// <summary>
        /// Back button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// gurantee for async operation for updating the sniffers
        /// </summary>
        /// <param name="p"></param>
        delegate void refresh(Packet p);

        /// <summary>
        /// The function that invoke the event gurantee for async operation for updating the sniffers
        /// </summary>
        /// <param name="sniffer"></param>
        /// <param name="p"></param>
        private void onNewPacket(Sniffer sniffer,Packet p)
        {

            this.Dispatcher.Invoke(new refresh(onRefresh), p);

        }

        /// <summary>
        /// refreshing and invoke the func that add packet to the SniffingDetailsListBox
        /// </summary>
        /// <param name="p"></param>
        private void onRefresh(Packet p)
        {

            addAndUpdatePackets(p);


        }

        /// <summary>
        /// add to packet datails to SniffingDetailsListBox
        /// </summary>
        /// <param name="p"></param>
        private void addAndUpdatePackets(Packet p)
        {
            if(p.Des_PORT=="12321")
                this.SniffingDetailsListBox.Items.Add(p.getCharString());
        }
    }
}
