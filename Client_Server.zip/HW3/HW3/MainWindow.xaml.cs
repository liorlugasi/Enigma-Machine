﻿using PcapDotNet.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static HW3.Sniffer;

namespace HW3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //for question 1//
        Server server { get; set; }
        Client client { get; set; }
        Timer ServerTimer { get; set; }
        Timer ClientTimer { get; set; }
        public static int timer { get; set; }   //Sequence Number
        //for question 2//
        List<byte[]> BytesPieces = new List<byte[]>();


        public MainWindow()
        {
            InitializeComponent();
            //for question 1//
            server = new Server(new IPEndPoint(IPAddress.Any, 12321));
            client = Client.ServerConnction("192.168.43.57", 12321);    //replace the IP to the one of your pc
            ServerTimer = new Timer(1000);
            ServerTimer.Enabled = true;
            ServerTimer.Elapsed += ServerTimer_ElapsedAsync; //conncet servertimer to the func ServerTimer_Elapsed
            ServerTimer.Start();
            ClientTimer = new Timer(3000);
            ClientTimer.Enabled = true;
            ClientTimer.Elapsed += ClientTimer_Elapsed;     //here is the line you should put in notes for invoke Q2


        }

        /// <summary>
        /// every 3 seconds the client automatically send message
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ClientTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            string msg = "test";
            if (msg.Length<=100)
                await client.SendMsg("packet numer " + timer.ToString() + ": " + msg); 
            else                            //if the packet morew then 100 bytes
            {
                int counter = 0;
                string msgs = "";
                int part = 1;
                for (int i = 0; i < msg.Length; i++)
                {
                    if (counter == 100 || i == msg.Length - 1)
                    {
                        int num = msgs.Length;
                        await client.SendMsg("packet numer " + timer.ToString()  +" part #" + part + ": " + msgs); 
                        counter = 0;
                        msgs = "";
                        part++;
                    }
                    else if (counter < 100)
                    {
                        msgs += msg[i];
                        counter++;
                    }

                }
            }
            timer++;
        }


       

        /// <summary>
        /// the server check all the time for messages
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ServerTimer_ElapsedAsync(object sender, ElapsedEventArgs e)
        {
            UdpReceiveResult udpReceiveResult = await server.udpClient.ReceiveAsync();//waiting for answer from the server to the client 
            await ServerListBox.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(() => {
                    ServerListBox.Items.Add(string.Format("client:{0}",
                        Encoding.ASCII.GetString(udpReceiveResult.Buffer, 0, udpReceiveResult.Buffer.Length)));
                }));
            await ClientListBox.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(() => {
                    ClientListBox.Items.Add(string.Format("Server recieved client packet #"+(timer).ToString(),
                        Encoding.ASCII.GetString(udpReceiveResult.Buffer, 0, udpReceiveResult.Buffer.Length)));
                }));

        }

        /// <summary>
        /// Client send message by the user textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            string msg = TextBoxClient.Text;
            if (msg.Length <= 100)
                await client.SendMsg("packet numer " + timer.ToString() + ": " + msg);
            else                                                //if the packet morew then 100 bytes
            {
                int part = 1;
                int counter = 0;
                string msgs = "";
                for (int i = 0; i < msg.Length; i++)
                {
                    if (counter == 100 || i == msg.Length - 1)
                    {
                        int num = msgs.Length;
                        await client.SendMsg("packet numer " + timer.ToString()+" part #"+part + ": " + msgs);
                        counter = 0;
                        msgs = "";
                        part++;
                    }
                    else if (counter < 100) {
                        msgs+= msg[i];
                        counter++;
                    }
                    
                }
            }
            timer++;
        }

        /// <summary>
        /// start and show sniffing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SniffingWindow sniffingWindow = new SniffingWindow();
            sniffingWindow.Show();
        }

        /// <summary>
        /// exit program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }


        /// <summary>
        /// Show task 2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Adversary();
        }


        /// <summary>
        /// for question 2
        /// </summary>
        public async void Adversary()
        {
            timer++;
            string PacketMessage = "aaaaabbbbbccccc";
            int d = new Random().Next(1, PacketMessage.Length);
            int pieces = PacketMessage.Length / d;
            List<string> ArrPieces = new List<string>();
            for (var i = 0; i < PacketMessage.Length; i += pieces)
            {
                ArrPieces.Add(PacketMessage.Substring(i, Math.Min(pieces, PacketMessage.Length - i)));
            }
            foreach (var item in ArrPieces)
            {
                BytesPieces.Add(Encoding.ASCII.GetBytes(item));
            }
            byte[] e = FuncXor(BytesPieces[0], BytesPieces[1]);

            for (int i = 2; i < BytesPieces.Count; i++)
            {
                e = FuncXor(e, BytesPieces[i]);
            }
            int LossPacket = new Random().Next(0, ArrPieces.Count);
            for (int i = 0; i < ArrPieces.Count; i++)
            {
                if (i != LossPacket)
                    await client.SendMsg(/*client.udpClient, (i + 1) + ";" + */ArrPieces[i] + Encoding.ASCII.GetString(e));

            }
            await client.SendMsg(client.udpClient, "The Missing Packet: " + Missing(LossPacket, e));
            Question2Butoon.IsEnabled= false;

        }

        /// <summary>
        /// Add zero
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        public string Zero(int size)
        {
            string Zero = "";
            for (int i = 0; i < size; i++)
            {
                Zero += "0";
            }
            return Zero;
        }


        /// <summary>
        /// Func that represent xor action
        /// </summary>
        /// <param name="Item1"></param>
        /// <param name="Item2"></param>
        /// <returns></returns>
        public byte[] FuncXor(byte[] Item1, byte[] Item2)
        {
            string sToHex = "";
            string sToHex2 = "";
            for (int i = 0; i < (Item1.Length != Item2.Length ? Item1.Length : Item2.Length); i++)
            {
                sToHex += Item1[i] - 48 < 10 ? (Item1[i] - 48).ToString() : Item1[i].ToString("X2");
                if (Item2.Length > i)
                    sToHex2 += Item2[i].ToString("X2");
            }
            long num1 = Convert.ToInt64(sToHex, 16);
            long num2 = Convert.ToInt64(sToHex2, 16);
            long result = num1 ^ num2;
            return Encoding.ASCII.GetBytes(result.ToString("X"));
        }


        /// <summary>
        /// Func the gets byte and return string
        /// </summary>
        /// <param name="ba"></param>
        /// <returns></returns>
        public static byte[] ByteString(byte[] ba)
        {
            string str = string.Empty;
            foreach (var item in ba)
            {
                str += (item - 48);
            }
            return HexBytes(str);
        }


        /// <summary>
        /// get hex and return byte
        /// </summary>
        /// <param name="hexString"></param>
        /// <returns></returns>
        public static byte[] HexBytes(string hexString)
        {
            var bytes = new byte[hexString.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                string currentHex = hexString.Substring(i * 2, 2);
                bytes[i] = Convert.ToByte(currentHex, 16);
            }
            return bytes;
        }

        /// <summary>
        /// add zero to bytes
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>

        public byte[] AddBytesZero(int size)
        {
            List<byte> Zero = new List<byte>();
            for (int i = 0; i < size; i++)
            {
                Zero.Add(Convert.ToByte(0));
            }
            return Zero.ToArray();
        }


        /// <summary>
        /// for returning the missing packet
        /// </summary>
        /// <param name="lossPacket"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public string Missing(int lossPacket, byte[] e)
        {
            int j = 0;
            if (lossPacket == 0)
                j = 1;

            byte[]  strBytes = FuncXor(e, BytesPieces[j]);


            for (int i = j + 1; i < BytesPieces.Count; i++)
            {
                if (i != lossPacket)
                    strBytes = FuncXor(strBytes, BytesPieces[i]);
            }
            string s = Encoding.ASCII.GetString(ByteString(strBytes));
            return s;
        }
    }
}
