﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    public class Client
    {
        public UdpClient udpClient { get; set; }
        
        public static Client ServerConnction (string hostname, int port)
        {
            Client client = new Client();
            client.udpClient = new UdpClient();
            client.udpClient.Connect(hostname, port);
            return client;
        }

        /// <summary>
        /// Send message to the server
        /// </summary>
        /// <param name="Msg"></param>
        /// <param name="iPEndPoint"></param>
        public async Task SendMsg(string Msg)
        {
            byte[] MsgBytes = Encoding.ASCII.GetBytes(Msg);
            await udpClient.SendAsync(MsgBytes, MsgBytes.Length);
        }

        public async Task<int> SendMsg(UdpClient Client, string msg)
        {
            byte[] msgInBytes = Encoding.ASCII.GetBytes(msg);
            return await Client.SendAsync(msgInBytes, msgInBytes.Length);
        }

    }
}
