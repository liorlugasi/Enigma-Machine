﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    /// <summary>
    /// for Question 1
    /// Class for sniffing
    /// </summary>
    class Sniffer
    {
        private Socket SnifferSocket;
        private IPAddress ipAddress;
        private byte[] buffer;
        private const int SECURITY_BUILTIN_DOMAIN_RID = 0x20;
        private const int DOMAIN_ALIAS_RID_ADMINS = 0x220;
        private const int IOC_VENDOR = 0x18000000;
        private const int IOC_IN = -2147483648; //0x80000000;
        private const int SIO_RCVALL = IOC_IN | IOC_VENDOR | 1;
        private const int BUF_SIZE = 1024 * 1024;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="ip"></param>
        public Sniffer(IPAddress ip)
        {
            this.ipAddress = ip;
            this.buffer = new byte[BUF_SIZE];
        }

        /// <summary>
        /// Dtor for stop sniffing
        /// </summary>
        ~Sniffer()
        {
            stop();
        }

        /// <summary>
        /// invoke the sniffing action
        /// </summary>
        public void start()
        {
            if (SnifferSocket == null)
            {
                try
                {

                    if (ipAddress.AddressFamily == AddressFamily.InterNetwork)
                    {
                        SnifferSocket = new Socket(AddressFamily.InterNetwork, SocketType.Raw, System.Net.Sockets.ProtocolType.IP);
                    }
                    else
                    {
                        SnifferSocket = new Socket(AddressFamily.InterNetworkV6, SocketType.Raw, System.Net.Sockets.ProtocolType.IP);
                    }
                    SnifferSocket.Bind(new IPEndPoint(ipAddress, 0));
                    SnifferSocket.IOControl(SIO_RCVALL, BitConverter.GetBytes((int)1), null); //the sniffing action
                    SnifferSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), null);    //steel packets
                }
                catch (Exception e)
                {
                    if (SnifferSocket!=null)
                    {
                        SnifferSocket.Close();
                        SnifferSocket = null;
                        Console.WriteLine(e.ToString());
                    }
                    
                }
            }
        }

        /// <summary>
        /// stop sniffing
        /// </summary>
        public void stop()
        {
            if (SnifferSocket != null)
            {
                SnifferSocket.Close();
                SnifferSocket = null;
            }
        }

        /// <summary>
        /// A packet recieve to the snifffer
        /// </summary>
        /// <param name="ar"></param>
        private void OnReceive(IAsyncResult ar)
        {
            try
            {
                int len = SnifferSocket.EndReceive(ar);
                if (SnifferSocket != null)
                {
                    byte[] receivedBuffer = new byte[len];
                    Array.Copy(buffer, 0, receivedBuffer, 0, len);
                    try
                    {
                        Packet packet = new Packet(receivedBuffer);
                        OnNewPacket(packet);
                    }
                    catch (ArgumentNullException ane)
                    {
                        Console.WriteLine(ane.ToString());
                    }
                    catch (ArgumentException ae)
                    {
                        Console.WriteLine(ae.ToString());
                    }
                }
                SnifferSocket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), null);
            }
            catch
            {
                stop();
            }
        }

        /// <summary>
        /// func for event handler and the packet
        /// </summary>
        /// <param name="p"></param>
        public void OnNewPacket(Packet p) => newPacketEventHandler?.Invoke(this, p);

        /// <summary>
        /// event for new packet
        /// </summary>
        public event NewPacketEventHandler newPacketEventHandler;

        /// <summary>
        /// reference to method
        /// </summary>
        /// <param name="Sniffer"></param>
        /// <param name="p"></param>
        public delegate void NewPacketEventHandler(Sniffer Sniffer, Packet p);

        /// <summary>
        /// check whether the current user is an administrator or not;
        /// </summary>
        /// <returns></returns>
        private bool IsUserAnAdmin()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        [DllImport("advapi32.dll")]
        private extern static int AllocateAndInitializeSid(byte[] pIdentifierAuthority, byte nSubAuthorityCount, int dwSubAuthority0, int dwSubAuthority1, int dwSubAuthority2, int dwSubAuthority3, int dwSubAuthority4, int dwSubAuthority5, int dwSubAuthority6, int dwSubAuthority7, out IntPtr pSid);


        [DllImport("advapi32.dll")]
        private extern static int CheckTokenMembership(IntPtr TokenHandle, IntPtr SidToCheck, ref int IsMember);


        [DllImport("advapi32.dll")]
        private extern static IntPtr FreeSid(IntPtr pSid);
    }
}
