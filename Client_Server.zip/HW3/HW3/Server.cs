﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    public class Server
    {
        public UdpClient udpClient { get; set; }
        public IPEndPoint Sender { get; set; }

        //q2//
        public string d { get; set; }
        public List<string> arr { get; set; }
        

        /// <summary>
        /// This Ctor initialize the client that listens and the client using udp protocol
        /// </summary>
        /// <param name="iPEndPoint"></param>
        public Server(IPEndPoint iPEndPoint)
        {
            udpClient = new UdpClient(iPEndPoint);
            Sender = iPEndPoint;
        }

        /// <summary>
        /// Reply message to the client
        /// </summary>
        /// <param name="Msg"></param>
        /// <param name="iPEndPoint"></param>
        public async void ReturnMsg(string Msg)
        {
            byte[] MsgBytes = Encoding.ASCII.GetBytes(Msg);
            await udpClient.SendAsync(MsgBytes, MsgBytes.Length);
        }


        //public string Recover(List<string> arrToSend, string Msg)
        //{
        //    d = Msg;
        //    int index = 0;
        //    foreach (var item in arrToSend)
        //    {
        //        foreach (var v in item)
        //        {
        //            if (v==';')
        //            {
        //                index++;
        //                break;
        //            }
        //            index++;
        //        }
        //        break;
        //    }
        //    byte[] e = Encoding.ASCII.GetBytes(arrToSend[0].Substring(index, arrToSend[0].Count() - index));
        //    List<byte[]> list = new List<byte[]>();
        //    foreach (var item in arrToSend)
        //    {
        //        list.Add(Encoding.ASCII.GetBytes(item.Split(';').ToString()));
        //    }
        //    index = 0;
        //    foreach (var item in list)
        //    {
        //        if (index.ToString()==item[0].ToString())
        //        {
        //            string temp = item.ToString().Substring(1);
        //            e = Xor(e, Encoding.ASCII.GetBytes(temp));
        //        }
        //    }
            
        //    return e.ToString();
        //}

        //public byte[] Xor(byte[] Item1, byte[] Item2)
        //{
        //    string hex1 = "";
        //    string hex2 = "";
        //    for (int i = 0; i < (Item1.Length != Item2.Length ? Item1.Length : Item2.Length); i++)
        //    {
        //        hex1 += Item1[i] - 48 < 10 ? (Item1[i] - 48).ToString() : Item1[i].ToString("X2");
        //        if (Item2.Length > i)
        //            hex2 += Item2[i].ToString("X2");
        //    }
        //    long dec1 = Convert.ToInt64(hex1, 16);
        //    long dec2 = Convert.ToInt64(hex2, 16);
        //    long result = dec1 ^ dec2;
        //    return Encoding.ASCII.GetBytes(result.ToString("X"));
        //}
    }
}
