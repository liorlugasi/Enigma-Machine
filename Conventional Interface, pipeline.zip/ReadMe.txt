Chapter 1: Data abstraction, immutable data.

Chapter 2: Conventional Interface, pipeline.

Chapter 3: Mutable data, message passing, dispatch function, dispatch dictionary.

Chapter 4:  iterator_map_reverse.