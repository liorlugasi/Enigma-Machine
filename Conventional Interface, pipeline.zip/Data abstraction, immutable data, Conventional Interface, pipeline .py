"""Assignment: 3 Campus: Beer Sheva Author: Lior lugasi, ID: 203962006"""
#------------q1------------#
def make_date(year=0,month=0,day=0):
    """Function that create the date"""        
    def dispatch(message):
        """Operate the actions with the function "dispatch" that gets message represent name of an action"""
        if message==0:
            return(year)
        if message==1:
            return(month)
        if message==2:
            return(day)
    return dispatch                #Returns the function dispatch#
def year(d):
    """Returns year"""        
    return (d(0))
def month(d):
    """Returns month"""
    if (d(1)==1):
        return('January')
    if (d(1)==2):
        return('February')
    if (d(1)==3):
        return('March')
    if (d(1)==4):
        return('April')
    if (d(1)==5):
        return('May')
    if (d(1)==6):
        return('June')
    if (d(1)==7):
        return('July')
    if (d(1)==8):
        return('August')
    if (d(1)==9):
        return('September')
    if (d(1)==10):
        return('October')
    if (d(1)==11):
        return('November')
    if (d(1)==12):
        return('December')
    
def day(d):
    """Returns day"""
    return (d(2))
    
def str_date(d):
    """Returns the date"""
    return('{0:}th of {1:}, {2:}'.format(day(d), month(d),year(d)))


#------------q2------------#
def data_preprocessing(data):
    """Reading and changing values, removing incorrect entries and completion of missing values"""
    data=data.split(';')
    data=list(filter(lambda x:'//' not in x and '..' not in x,data))
    data=list(map(lambda x:  x+'txt' if x.endswith('.') else x, data ))
    return data

def data_preprocessing_file_types(data):
    """This function is calculate the amount of file types"""
    data=data_preprocessing(data)
    data=list(filter(lambda x:'.' in x,data))
    data=list(map(lambda x: tuple(x.split('.'))[-1],data))
    data = list(set(map(lambda x: (x,data.count(x)),data)))
    return data

def data_preprocessing_tree(data):
    """This function is for build a tree for normalized data"""
    data=data_preprocessing(data)
    data=list(map(lambda x:tuple(x.rsplit('/',1)) if x.endswith('txt') or x.endswith('zip') or x.endswith('py') else (x,),data))
    temp1=lambda x: tuple(filter(lambda y: y!=None,map(lambda q:q[1]if len(q)>1 and q[0]==x[0] else None,data)))
    temp2=lambda x:(x[0],temp1(x))
    data=list(set(map(temp2,data)))
    return data

#------------q3------------#
def make_currency(amount=0,symbol=''):
    """Function that create the amount and it's symbol"""      
    def set_value(mas,value):
        """Change the amount or the symbol"""       
        nonlocal amount,symbol
        if mas=='amount':           
            amount = value
        if(mas=='symbol'):
            symbol=value
    def get_value(mas):
        """#Returns the amount or the symbol"""             
        if mas=='amount':
            return amount
        if mas=='symbol':
            return symbol
    def str():
        """Returns string includes the amount and the symbol"""                              
        print('{0}{1}'.format(symbol,amount))
    def convert(f,newsymbol):
        """Change the Currency rate"""           
        set_value('symbol', newsymbol)
        set_value('amount',f(get_value('amount')))
    def dispatch(message):
        """Operate the actions with the function "dispatch" that gets message represent name of an action"""  
        if message=='get_value':
            return get_value
        if message=='set_value':
            return set_value
        if message=='str':
            return str()
        if message=='convert':
            return convert
    return dispatch


#------------q4------------#
def get_reverse_map_iterator(s,g=lambda x:x):  
    """Represent the index"""
    counter=len (s)                   
    def next():
        """Return The next element"""
        nonlocal counter        
        if counter==0:         #If it reach to the start of the list#
            return 'no more items'
        temp=s[counter-1]     #Else, return the action element consisting of a function on element from the list#
        temp=g(temp)
        counter-=1      #Increase the counter
        return temp
    def has_more():   
        """Return True it dosen't reach to the start of the list"""      
        if counter==0:
            return False
        return True
    return{'has_more':has_more,'next':next}
    
#------------q5------------#
def make_mutable_rlist(my_list=None):
    """Return a functional implementation of a mutable recursive list."""
    contents = empty_rlist
    if my_list!=None:
        """Copy constructor"""
        i=my_list['length']()-1
        while i>=0:
            contents=make_rlist(my_list['get_item'](i),contents)
            i-=1
    def length():
        """Returns the length of the list"""
        return len_rlist(contents)
    def get_item(ind):
        """Returns item by index"""
        return getitem_rlist(contents, ind)
    def push_first(value):
        """Push element to the list"""
        nonlocal contents
        contents = make_rlist(value, contents)
    def pop_first():
        """Pop element from the list"""
        nonlocal contents
        f = first(contents)
        contents = rest(contents)
        return f
    def strr():
        """Function that return a string that represents a list """
        str2=[]
        for i in range(length()):
            str2=str2+[get_item(i)]
        return str(str2)
    
    def slice(first, last):
        """Function that returns sub-List similar to slicing operator"""
        i=last-1
        temp= make_mutable_rlist()
        while i >= first:
            temp['push_first'](get_item(i))
            i-=1
        return temp
    def extend(ext):
        """Function that allows to get an object of mutable_list with some elements and put them at the end of the list according to the order"""
        i=ext['length']()-1
        nonlocal contents
        while i>=0:
            contents=make_rlist(ext['get_item'](i),contents)
            i-=1
    def get_iterator():
        """Function that returns the contents of the list """
        counter=0
        def next():
            """Return The next element"""
            nonlocal counter
            if counter==len_rlist(contents):         #If it reach to the start of the list#
                return 'no more items'
            counter+=1      #Increase the counter
            return(getitem_rlist(contents, counter-1))     #Else, return the action element consisting of a function on element from the list#
        def hasNext():
            """Return True it dosen't reach to the start of the list"""   
            if counter==len_rlist(contents):
                return False
            return True
        return{'hasNext':hasNext,'next':next}
        
    return {'length':length, 'get_item':get_item, 'push_first':push_first,'pop_first': pop_first, 'str':strr,
             'slice':slice, 'extend':extend, 'get_iterator': get_iterator}
        

empty_rlist = None

def make_rlist(first, rest):
    """Make a recursive list from its first     element and the rest."""
    return (first, rest)

def first(s):
    """Return the first element of a recursive     list s."""
    return s[0]

def rest(s):
    """Return the rest of the elements of a     recursive list s."""
    return s[1]

def len_rlist(s):
    """Return the length of recursive list s."""
    length = 0
    while s != empty_rlist:
        s, length = rest(s), length + 1
    return length

def getitem_rlist(s, i):
    """Return the element at index i of recursive list s."""
    while i > 0:
        s, i = rest(s), i - 1
    return first(s)



